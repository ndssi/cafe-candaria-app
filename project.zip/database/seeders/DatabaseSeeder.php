<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    // public function run(): void
    // {
    //     // Membuat akun admin bawaan
    //     User::create([
    //         'name'     => 'Admin Cafe Candaria',
    //         'email'    => 'admin@candaria.com',
    //         'password' => Hash::make('admin123'),
    //     ]);
    // }
}