<?php echo $__env->make('admin.jamoperasional', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH C:\laragon\www\cafe-candaria\resources\views/admin/jam-operasional.blade.php ENDPATH**/ ?>