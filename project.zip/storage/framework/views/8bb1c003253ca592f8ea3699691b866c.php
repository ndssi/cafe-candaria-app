<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login Admin Panel - Cafe Candaria</title>
  <link rel="stylesheet" href="/css/login.css">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,400;0,600;0,700;1,600&display=swap" rel="stylesheet">
</head>
<body class="login-body">

  <div class="login-card">
    <!-- Accent Line Orange di atas kartu -->
    <div class="card-top-accent"></div>

    <!-- Logo & Header -->
    <div class="login-header">
      <img src="<?php echo e(asset('images/logo.png')); ?>" style="width: 90px; height: auto; margin-bottom: 15px;">
      <h1 class="brand-title">Cafe Candaria</h1>
      <p class="brand-subtitle">ADMIN PANEL - SMKN 2 PURWAKARTA</p>
    </div>

   <!-- Form Login (Langsung pindah ke halaman dashboard) -->
<form action="<?php echo e(route('admin.dashboard')); ?>" method="GET" class="login-form">
  <div class="form-group">
    <label for="username">USERNAME</label>
    <input type="text" id="username" name="username" required autocomplete="off">
  </div>

  <div class="form-group">
    <label for="password">PASSWORD</label>
    <input type="password" id="password" name="password" required>
  </div>

  <div class="button-group">
    <button type="submit" class="btn-masuk">MASUK</button>
  </div>
</form><?php /**PATH C:\laragon\www\cafe-candaria\resources\views/admin/login.blade.php ENDPATH**/ ?>