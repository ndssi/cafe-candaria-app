<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Galeri - Cafe Candaria</title>
    
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- File CSS Eksternal -->
    <link rel="stylesheet" href="<?php echo e(asset('css/galeri.css')); ?>">
</head>
<body>

<div class="dashboard-container">
    
    <!-- ================= SIDEBAR ================= -->
    <aside class="sidebar">
        <div>
            <!-- Brand Badge -->
            <div class="brand-logo-container">
                <div class="brand-badge">
                    <img src="<?php echo e(asset('images/logo.png')); ?>" alt="Logo" onerror="this.src='https://via.placeholder.com/35x40?text=LOGO'">
                    <div class="brand-text">
                        <h1>Cafe Candaria</h1>
                        <p>SMKN 2 PURWAKARTA</p>
                    </div>
                </div>
            </div>

            <!-- List Menu -->
            <nav class="sidebar-menu">
                <div class="sidebar-title">MENU ADMIN</div>
                <ul class="sidebar-list">
                    <li><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                    <li><a href="<?php echo e(route('admin.profil')); ?>">Profil</a></li>
                    <li><a href="<?php echo e(route('admin.organigram')); ?>">Organigram</a></li>
                    <li><a href="<?php echo e(route('admin.menu')); ?>">Menu</a></li>
                    <li><a href="<?php echo e(route('admin.jam-operasional')); ?>">Jam Operasional</a></li>
                    <li class="active"><a href="<?php echo e(route('admin.galeri')); ?>">Galeri</a></li>
                </ul>
            </nav>
        </div>

        <!-- Tombol Logout -->
        <div class="logout-container">
            <form action="<?php echo e(route('logout')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn-logout">
                    <i class="fa-solid fa-right-from-bracket"></i> Logout
                </button>
            </form>
        </div>
    </aside>

    <!-- ================= MAIN CONTENT ================= -->
    <main class="main-content">
        <!-- Topbar -->
        <header class="topbar">
            <button class="toggle-btn" aria-label="Toggle Menu">
                <i class="fa-solid fa-bars"></i>
            </button>
            <div class="admin-pill">
                <i class="fa-solid fa-user"></i>
                <span>Admin</span>
            </div>
        </header>

        <!-- Card Wrapper -->
        <div class="content-card">
            <div class="card-header">
                <div class="subtitle">KELOLA</div>
                <h2 class="title">GALERI</h2>
                <p class="desc">Perbaharui galeri di bawah ini</p>
            </div>

            <!-- Gallery Cards Grid -->
            <div class="gallery-grid">
                
                <?php $__empty_1 = true; $__currentLoopData = $galleries ?? [1, 2, 3, 4]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="gallery-item">
                        <div class="img-wrapper">
                            <?php if(is_object($item) && !empty($item->gambar)): ?>
                                <img src="<?php echo e(asset('storage/' . $item->gambar)); ?>" alt="Foto Galeri" onerror="this.src='https://picsum.photos/300/200?random=<?php echo e($item->id); ?>'">
                            <?php else: ?>
                                <img src="https://picsum.photos/300/200?random=<?php echo e(is_object($item) ? $item->id : $item); ?>" alt="Foto Galeri">
                            <?php endif; ?>
                        </div>
                        
                        <div class="action-buttons">
                            <!-- Tombol Hapus menuju halaman konfirmasi hapusgaleri -->
                            <a href="<?php echo e(route('admin.galeri.hapus', is_object($item) ? $item->id : $item)); ?>" class="btn-action">
                                <i class="fa-solid fa-trash-can"></i> Hapus
                            </a>

                            <!-- Tombol Edit -->
                            <a href="<?php echo e(route('admin.galeri.edit', is_object($item) ? $item->id : $item)); ?>" class="btn-action">
                                <i class="fa-solid fa-pencil"></i> Edit
                            </a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p>Tidak ada data galeri.</p>
                <?php endif; ?>
            </div>
        </div>
    </main>

</div>

</body>
</html><?php /**PATH C:\laragon\www\cafe-candaria\resources\views/admin/galeri.blade.php ENDPATH**/ ?>