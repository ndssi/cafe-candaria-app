<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Tambah Menu - Cafe Candaria</title>
  <link rel="stylesheet" href="<?php echo e(asset('css/tambahorganigram.css')); ?>">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,400;0,500;0,600;0,700;1,600;1,700&display=swap" rel="stylesheet">
</head>
<body class="dashboard-body">

  <div class="admin-container">
    <!-- SIDEBAR LEFT -->
    <aside class="sidebar">
      <div class="sidebar-top-content">
        <!-- LOGO BOX -->
        <div class="sidebar-logo-box">
          <img src="<?php echo e(asset('images/logo.png')); ?>" alt="Logo SMKN 2 Purwakarta" class="sidebar-logo">
          <div class="logo-text">
            <span class="brand-title-sidebar">Cafe Candaria</span>
            <span class="brand-sub-sidebar">SMKN 2 PURWAKARTA</span>
          </div>
        </div>

        <!-- MENU NAVIGATION -->
        <div class="sidebar-menu-wrapper">
          <h3 class="sidebar-section-title">MENU ADMIN</h3>
          <nav class="sidebar-nav">
            <a href="<?php echo e(route('admin.dashboard')); ?>" class="nav-item">Dashboard</a>
            <a href="<?php echo e(route('admin.profil')); ?>" class="nav-item">Profil</a>
            <a href="<?php echo e(route('admin.organigram')); ?>" class="nav-item">Organigram</a>
            <a href="<?php echo e(route('admin.menu')); ?>" class="nav-item active">Menu</a>
            <a href="<?php echo e(route('admin.jam-operasional')); ?>" class="nav-item">Jam Operasional</a>
            <a href="<?php echo e(route('admin.galeri')); ?>" class="nav-item">Galeri</a>
          </nav>
        </div>
      </div>

      <!-- LOGOUT BUTTON -->
      <div class="sidebar-bottom-logout">
        <form action="<?php echo e(route('logout')); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <button type="submit" class="btn-sidebar-logout">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
              <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path>
              <polyline points="16 17 21 12 16 7"></polyline>
              <line x1="21" y1="12" x2="9" y2="12"></line>
            </svg>
            <span>Logout</span>
          </button>
        </form>
      </div>
    </aside>

    <!-- MAIN CONTENT AREA -->
    <main class="main-content">
      <!-- TOP NAVBAR -->
      <header class="top-navbar">
        <button class="hamburger-btn" aria-label="Toggle Menu">
          <span></span>
          <span></span>
          <span></span>
        </button>

        <div class="top-right-section">
          <div class="admin-badge">
            <svg class="admin-icon" viewBox="0 0 24 24" fill="currentColor">
              <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>
            </svg>
            <span class="admin-text">Admin</span>
          </div>
        </div>
      </header>

      <!-- FORM ADD DATA CARD -->
      <div class="form-content-wrapper">
        <div class="form-card">
          <div class="form-header">
            <h2 class="form-title">Tambah Menu</h2>
            <p class="form-subtitle">Tambahkan menu baru di bawah ini</p>
          </div>

          <form action="<?php echo e(route('admin.menu.store')); ?>" method="POST" class="add-data-form">
            <?php echo csrf_field(); ?>
            
            <div class="form-group">
              <label for="nama_menu" class="form-label">Nama Menu</label>
              <input type="text" id="nama_menu" name="nama_menu" class="form-control" placeholder="Contoh: Es Tea Jus" required>
            </div>

            <div class="form-group">
              <label for="kategori" class="form-label">Kategori</label>
              <select id="kategori" name="kategori" class="form-control" required>
                <option value="Minuman">Minuman</option>
                <option value="Makanan">Makanan</option>
              </select>
            </div>

            <div class="form-group">
              <label for="harga" class="form-label">Harga (Rp)</label>
              <input type="number" id="harga" name="harga" class="form-control" placeholder="Contoh: 5000" required>
            </div>

            <div class="form-actions">
              <a href="<?php echo e(route('admin.menu')); ?>" class="btn-cancel">Batal</a>
              <button type="submit" class="btn-submit">Simpan Menu</button>
            </div>
          </form>
        </div>
      </div>
    </main>
  </div>

</body>
</html>

<?php /**PATH C:\laragon\www\cafe-candaria\resources\views/admin/tambahmenu.blade.php ENDPATH**/ ?>