<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cafe Candaria - SMKN 2 Purwakarta</title>
    <!-- Font Google -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@1,600;1,700&family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <!-- Font Awesome Icon -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        :root {
            --primary-green: #297637;
            --dark-green: #1d5828;
            --light-green: #d6ebd0;
            --accent-gold: #c39c36;
            --text-dark: #2c3e50;
            --text-muted: #555555;
            --radius-md: 14px;
            --radius-lg: 20px;
            --shadow-sm: 0 4px 14px rgba(0, 0, 0, 0.08);
            --shadow-md: 0 8px 22px rgba(0, 0, 0, 0.12);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        html, body {
            width: 100%;
            overflow-x: hidden; /* Mencegah scroll ke samping */
            background-color: #ffffff;
            color: var(--text-dark);
            scroll-behavior: smooth;
        }

        a {
            text-decoration: none;
            color: inherit;
        }

        /* CONTAINER KONTEN AGAR TETAP RAPI DI TENGAH */
        .container {
            width: 100%;
            max-width: 1100px;
            margin: 0 auto;
            padding: 0 20px;
        }

        /* ---------------- NAVBAR (FULL WIDTH) ---------------- */
        .navbar {
            width: 100%;
            background-color: var(--primary-green);
            position: sticky;
            top: 0;
            z-index: 1000;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .navbar-wrapper {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 14px 20px;
            max-width: 1200px;
            margin: 0 auto;
        }

        .navbar .logo {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .navbar .logo img {
            width: 42px;
            height: 42px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid #fff;
        }

        .navbar .logo h2 {
            font-size: 1.15rem;
            color: #ffffff;
            font-weight: 700;
            line-height: 1.1;
        }

        .navbar .logo span {
            font-size: 0.7rem;
            color: #d8edd1;
            letter-spacing: 0.8px;
        }

        .navbar nav ul {
            display: flex;
            list-style: none;
            gap: 24px;
        }

        .navbar nav ul li a {
            color: #ffffff;
            font-size: 0.82rem;
            font-weight: 600;
            letter-spacing: 0.5px;
            transition: color 0.2s;
        }

        .navbar nav ul li a:hover,
        .navbar nav ul li a.active {
            color: #ffe885;
        }

        /* ---------------- HERO SECTION (FULL WIDTH) ---------------- */
        .hero {
            width: 100%;
            background-color: var(--light-green);
            position: relative;
            padding: 75px 20px 85px;
            text-align: center;
            overflow: hidden;
        }

        .circle {
            position: absolute;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.45);
            pointer-events: none;
        }

        .circle-left {
            width: 450px;
            height: 450px;
            top: -120px;
            left: -100px;
        }

        .circle-right {
            width: 500px;
            height: 500px;
            bottom: -150px;
            right: -100px;
        }

        .hero-content {
            position: relative;
            z-index: 2;
            max-width: 650px;
            margin: 0 auto;
        }

        .sub-title {
            font-size: 0.85rem;
            font-weight: 700;
            letter-spacing: 2px;
            color: var(--dark-green);
            margin-bottom: 8px;
        }

        .hero h1 {
            font-size: 2.1rem;
            font-weight: 700;
            line-height: 1.25;
            color: #213326;
        }

        .hero .brand-name {
            font-family: 'Playfair Display', serif;
            font-style: italic;
            font-size: 2.6rem;
            color: var(--accent-gold);
            margin-bottom: 14px;
        }

        .hero .description {
            font-size: 0.95rem;
            color: #435548;
            line-height: 1.6;
            margin-bottom: 25px;
        }

        .hero-buttons {
            display: flex;
            justify-content: center;
            gap: 16px;
            margin-bottom: 12px;
        }

        .btn {
            padding: 9px 30px;
            border-radius: 30px;
            font-size: 0.9rem;
            font-weight: 600;
            display: inline-block;
            transition: all 0.3s ease;
            cursor: pointer;
        }

        .btn-green {
            background-color: var(--primary-green);
            color: #ffffff;
            border: 2px solid var(--primary-green);
        }

        .btn-green:hover {
            background-color: var(--dark-green);
        }

        .btn-outline {
            background-color: #ffffff;
            color: var(--primary-green);
            border: 2px solid #ffffff;
        }

        .btn-outline:hover {
            background-color: transparent;
            border-color: var(--primary-green);
        }

        .hero-note {
            font-size: 0.72rem;
            color: #556b5b;
            margin-top: 10px;
        }

        /* ---------------- SEJARAH / PROFIL (FULL WIDTH) ---------------- */
        .history-section {
            width: 100%;
            background-color: var(--primary-green);
            padding: 55px 0 65px;
            text-align: center;
            color: #ffffff;
        }

        .hero-banner {
            max-width: 820px;
            margin: 0 auto 28px;
            border-radius: var(--radius-md);
            overflow: hidden;
            box-shadow: var(--shadow-md);
        }

        .hero-banner img {
            width: 100%;
            height: 350px;
            object-fit: cover;
            display: block;
        }

        .history-section h2 {
            font-size: 1.45rem;
            font-weight: 700;
            letter-spacing: 1px;
            margin-bottom: 16px;
            text-transform: uppercase;
        }

        .history-desc {
            max-width: 820px;
            margin: 0 auto 35px;
            font-size: 0.92rem;
            line-height: 1.7;
            color: #ebf5ee;
        }

        .leadership-cards {
            display: flex;
            justify-content: center;
            gap: 25px;
            flex-wrap: wrap;
        }

        .profile-card {
            background-color: #ffffff;
            color: var(--text-dark);
            border-radius: var(--radius-md);
            padding: 24px 20px;
            width: 240px;
            text-align: center;
            box-shadow: var(--shadow-sm);
        }

        .avatar-placeholder {
            width: 70px;
            height: 70px;
            border-radius: 50%;
            background-color: #d0d2d6;
            margin: 0 auto 14px;
        }

        .profile-card h3 {
            font-size: 0.8rem;
            color: #666;
            margin-bottom: 4px;
            font-weight: 500;
        }

        .profile-card p {
            font-size: 1rem;
            font-weight: 600;
            color: #212529;
        }

        /* ---------------- MENU SECTION (FULL WIDTH) ---------------- */
        .menu-section {
            width: 100%;
            padding: 65px 0;
            text-align: center;
            background-color: #ffffff;
        }

        .section-subtitle {
            font-size: 0.82rem;
            font-weight: 700;
            letter-spacing: 1.5px;
            color: var(--primary-green);
        }

        .section-title {
            font-family: 'Playfair Display', serif;
            font-style: italic;
            font-size: 2rem;
            color: var(--accent-gold);
            margin-bottom: 35px;
        }

        .menu-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 24px;
            max-width: 850px;
            margin: 0 auto;
        }

        .menu-card {
            background-color: #ffffff;
            border-radius: var(--radius-md);
            border: 1px solid #e3e9e4;
            padding: 14px;
            text-align: center;
            box-shadow: var(--shadow-sm);
            transition: transform 0.2s, box-shadow 0.2s;
        }

        .menu-card:hover {
            transform: translateY(-4px);
            box-shadow: var(--shadow-md);
        }

        .menu-img {
            width: 100%;
            height: 145px;
            border-radius: 10px;
            overflow: hidden;
            margin-bottom: 12px;
            background-color: #f5f5f5;
        }

        .menu-img img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .menu-card .category {
            display: inline-block;
            font-size: 0.72rem;
            font-weight: 700;
            color: var(--primary-green);
            letter-spacing: 0.6px;
            margin-bottom: 4px;
        }

        .menu-card h4 {
            font-size: 1rem;
            font-weight: 600;
            color: #222;
            margin-bottom: 4px;
        }

        .menu-card .price {
            font-size: 0.88rem;
            font-weight: 500;
            color: #555;
        }

        /* PAGINATION MENU CONTROLS */
        .menu-pagination-controls {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 16px;
            margin-top: 26px;
        }

        .page-btn {
            background-color: var(--primary-green);
            color: #fff;
            border: none;
            padding: 8px 20px;
            font-size: 0.85rem;
            font-weight: 600;
            border-radius: 20px;
            cursor: pointer;
            transition: 0.2s;
        }

        .page-btn:disabled {
            background-color: #c4d7c7;
            cursor: not-allowed;
        }

        .page-info {
            font-size: 0.85rem;
            font-weight: 600;
            color: var(--text-muted);
        }

        .more-menu-container {
            margin-top: 30px;
        }

        .btn-green-full {
            background-color: var(--primary-green);
            color: #ffffff;
            padding: 10px 34px;
            border-radius: 30px;
            font-size: 0.88rem;
            font-weight: 600;
            display: inline-block;
            box-shadow: 0 4px 12px rgba(41, 118, 55, 0.3);
            transition: background 0.3s;
        }

        .btn-green-full:hover {
            background-color: var(--dark-green);
        }

        /* ---------------- JAM OPERASIONAL & KONTAK (FULL WIDTH) ---------------- */
        .info-section {
            width: 100%;
            background-color: var(--primary-green);
            padding: 60px 0;
            text-align: center;
            color: #ffffff;
        }

        .info-subtitle {
            font-size: 0.8rem;
            letter-spacing: 1.5px;
            color: #d1e7dd;
            font-weight: 600;
        }

        .info-title {
            font-size: 1.6rem;
            font-weight: 700;
            margin-bottom: 35px;
        }

        .info-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 22px;
            max-width: 780px;
            margin: 0 auto;
        }

        .info-card {
            background-color: #ffffff;
            border-radius: var(--radius-md);
            padding: 24px 20px;
            color: var(--text-dark);
            box-shadow: var(--shadow-sm);
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }

        .info-card h4 {
            font-size: 1rem;
            font-weight: 600;
            margin-bottom: 8px;
            color: #212529;
        }

        .info-card p {
            font-size: 0.88rem;
            color: #555;
            line-height: 1.5;
        }

        .whatsapp-link {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            color: #128c7e !important;
            font-weight: 600;
            font-size: 0.92rem !important;
            margin-top: 6px;
        }

        /* ---------------- GALERI (FULL WIDTH) ---------------- */
        .gallery-section {
            width: 100%;
            padding: 65px 0;
            text-align: center;
            background-color: #ffffff;
        }

        .gallery-subtitle {
            font-size: 0.78rem;
            font-weight: 700;
            letter-spacing: 1.5px;
            color: #777;
        }

        .gallery-title {
            font-family: 'Playfair Display', serif;
            font-style: italic;
            font-size: 2rem;
            color: var(--accent-gold);
            margin-bottom: 6px;
        }

        .gallery-desc {
            font-size: 0.88rem;
            color: #666;
            margin-bottom: 35px;
        }

        .gallery-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
            max-width: 780px;
            margin: 0 auto;
        }

        .gallery-item {
            height: 170px;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: var(--shadow-sm);
        }

        .gallery-item img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: block;
            transition: transform 0.3s ease;
        }

        .gallery-item img:hover {
            transform: scale(1.04);
        }

        /* ---------------- FOOTER (FULL WIDTH) ---------------- */
        footer {
            width: 100%;
            background-color: var(--dark-green);
            color: #ffffff;
            text-align: center;
            padding: 35px 20px 22px;
        }

        footer h3 {
            font-family: 'Playfair Display', serif;
            font-style: italic;
            font-size: 1.7rem;
            color: var(--accent-gold);
            margin-bottom: 3px;
        }

        footer p {
            font-size: 0.75rem;
            letter-spacing: 1.5px;
            color: #d8edd1;
            margin-bottom: 20px;
            font-weight: 600;
        }

        footer .copyright {
            font-size: 0.75rem;
            color: #daeed8;
            border-top: 1px solid rgba(255, 255, 255, 0.15);
            padding-top: 16px;
        }

        /* ---------------- RESPONSIVE BREAKPOINTS ---------------- */
        @media (max-width: 900px) {
            .hero h1 { font-size: 1.8rem; }
            .hero .brand-name { font-size: 2.2rem; }
            .hero-banner img { height: 280px; }
            .menu-grid { grid-template-columns: repeat(2, 1fr); }
        }

        @media (max-width: 650px) {
            .navbar-wrapper {
                flex-direction: column;
                gap: 12px;
            }
            .navbar nav ul {
                gap: 15px;
                flex-wrap: wrap;
                justify-content: center;
            }
            .hero { padding: 50px 15px 60px; }
            .hero h1 { font-size: 1.5rem; }
            .hero .brand-name { font-size: 1.9rem; }
            .hero-banner img { height: 200px; }
            .menu-grid { grid-template-columns: 1fr; }
            .info-grid { grid-template-columns: 1fr; }
            .gallery-grid { grid-template-columns: 1fr; }
            .gallery-item { height: 160px; }
            .leadership-cards { flex-direction: column; align-items: center; }
            .profile-card { width: 100%; max-width: 300px; }
        }
    </style>
</head>

<body>

    <!-- NAVBAR (EDGE TO EDGE) -->
    <header class="navbar">
        <div class="navbar-wrapper">
            <div class="logo">
                <img src="<?php echo e(asset('images/logo.png')); ?>" onerror="this.src='images/logo.jpg'" alt="Logo Cafe Candaria">
                <div>
                    <h2>Cafe Candaria</h2>
                    <span>SMKN 2 PURWAKARTA</span>
                </div>
            </div>
            <nav>
                <ul>
                    <li><a href="#beranda" class="active">BERANDA</a></li>
                    <li><a href="#profil">PROFIL</a></li>
                    <li><a href="#menu">MENU</a></li>
                    <li><a href="#galeri">GALERI</a></li>
                    <li><a href="<?php echo e(route('admin.login')); ?>">LOGIN</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <!-- HERO SECTION (EDGE TO EDGE) -->
    <section class="hero" id="beranda">
        <div class="circle circle-left"></div>
        <div class="circle circle-right"></div>

        <div class="hero-content">
            <p class="sub-title">SMKN 2 PURWAKARTA</p>
            <h1>Halo, Selamat Datang<br>di</h1>
            <h1 class="brand-name">Cafe Candaria</h1>

            <p class="description">
                Tempat nongkrong nyaman dengan menu makanan & minuman pilihan. 
                Cek menu, jam buka, dan lokasi kami.
            </p>

            <div class="hero-buttons">
                <a href="#menu" class="btn btn-green">Menu</a>
                <a href="#profil" class="btn btn-outline">Profil</a>
            </div>
            <p class="hero-note">Buka setiap jam operasional kami</p>
        </div>
    </section>

    <!-- SEJARAH / PROFIL SECTION (EDGE TO EDGE) -->
    <section class="history-section" id="profil">
        <div class="container">
            <div class="hero-banner">
                <img src="<?php echo e(asset('images/cafe.jpg')); ?>" onerror="this.src='images/cafe.jpg'" alt="Foto Cafe Candaria">
            </div>

            <h2>SEJARAH CAFE CANDARIA</h2>
            <p class="history-desc">
                Cafe Candaria berawal dari kebutuhan siswa dan guru SMKN 2 Purwakarta akan tempat istirahat yang nyaman
                dengan menu yang enak dan terjangkau. Dari sinilah ide untuk menghadirkan kantin sekolah dengan konsep
                cafe modern muncul, memadukan pelayanan ramah dengan suasana yang hangat untuk mendukung aktivitas
                belajar sehari-hari.
            </p>

            <div class="leadership-cards">
                <div class="profile-card">
                    <div class="avatar-placeholder"></div>
                    <h3>PEMBINA</h3>
                    <p>Wulan Febrianti, S.Pd</p>
                </div>
                <div class="profile-card">
                    <div class="avatar-placeholder"></div>
                    <h3>Ketua</h3>
                    <p>Preti Nurfanjani</p>
                </div>
            </div>
        </div>
    </section>

    <!-- MENU SECTION (EDGE TO EDGE) -->
    <section class="menu-section" id="menu">
        <div class="container">
            <p class="section-subtitle">MENU</p>
            <h2 class="section-title">Cafe Candaria</h2>

            <!-- GRID MENU -->
            <div class="menu-grid" id="menuGrid">
                <!-- Card 1 -->
                <div class="menu-card">
                    <div class="menu-img">
                        <img src="<?php echo e(asset('images/TEH JUS.jpg')); ?>" onerror="this.src='images/teh jus.jpg'" alt="Es Tea Jus">
                    </div>
                    <span class="category">MINUMAN</span>
                    <h4>Es Tea Jus</h4>
                    <p class="price">Rp 2.000</p>
                </div>

                <!-- Card 2 -->
                <div class="menu-card">
                    <div class="menu-img">
                        <img src="<?php echo e(asset('images/CHOCOLATOS.jpg')); ?>" onerror="this.src='images/chocolatos.jpg'" alt="Es Chocolatos">
                    </div>
                    <span class="category">MINUMAN</span>
                    <h4>Es Chocolatos</h4>
                    <p class="price">Rp 2.000</p>
                </div>

                <!-- Card 3 -->
                <div class="menu-card">
                    <div class="menu-img">
                        <img src="<?php echo e(asset('images/R.jpg')); ?>" onerror="this.src='images/R.jpg'" alt="AQUA">
                    </div>
                    <span class="category">MINUMAN</span>
                    <h4>AQUA</h4>
                    <p class="price">Rp 2.000</p>
                </div>

                <!-- Card 4 -->
                <div class="menu-card">
                    <div class="menu-img">
                        <img src="<?php echo e(asset('images/DONAT.jpg')); ?>" onerror="this.src='images/donat.jpg'" alt="Donat">
                    </div>
                    <span class="category">MAKANAN</span>
                    <h4>Donat</h4>
                    <p class="price">Rp 4.000</p>
                </div>

                <!-- Card 5 -->
                <div class="menu-card">
                    <div class="menu-img">
                        <img src="<?php echo e(asset('images/pisang.jpg')); ?>" onerror="this.src='images/pisang.jpg'" alt="Pisang Crispi">
                    </div>
                    <span class="category">MAKANAN</span>
                    <h4>Pisang Crispi</h4>
                    <p class="price">Rp 4.000</p>
                </div>

                <!-- Card 6 -->
                <div class="menu-card">
                    <div class="menu-img">
                        <img src="<?php echo e(asset('images/DIMSUM.jpg')); ?>" onerror="this.src='images/dimsum.jpg'" alt="Dimsum">
                    </div>
                    <span class="category">MAKANAN</span>
                    <h4>Dimsum</h4>
                    <p class="price">Rp 7.000</p>
                </div>
            </div>

            <!-- KONTROL PAGINATION (Muncul otomatis jika item > 6) -->
            <div class="menu-pagination-controls" id="menuPagination" style="display: none;">
                <button class="page-btn" id="prevBtn" onclick="prevPage()">Sebelumnya</button>
                <span class="page-info" id="pageInfo">Halaman 1</span>
                <button class="page-btn" id="nextBtn" onclick="nextPage()">Selanjutnya</button>
            </div>

            <!-- BUTTON LIHAT SEMUA MENU -->
            <div class="more-menu-container">
                <a href="<?php echo e(route('detailmenu')); ?>" class="btn-green-full">Lihat Semua Menu</a>
            </div>
        </div>
    </section>

    <!-- JAM OPERASIONAL & KONTAK (EDGE TO EDGE) -->
    <section class="info-section">
        <div class="container">
            <p class="info-subtitle">KAPAN KAMI BUKA</p>
            <h2 class="info-title">Jam Operasional</h2>

            <div class="info-grid">
                <div class="info-card">
                    <h4>Senin - Jumat</h4>
                    <p>08.00 - 14.00</p>
                </div>
                <div class="info-card">
                    <h4>Sabtu - Minggu</h4>
                    <p>Tutup</p>
                </div>
                <div class="info-card">
                    <h4>ALAMAT</h4>
                    <p>Jln. Sadang Km 2, KK. Nagri Kaler, Kec. Purwakarta, Kabupaten Purwakarta, Jawa Barat 41115</p>
                </div>
                <div class="info-card">
                    <h4>Kontak</h4>
                    <a href="https://wa.me/" target="_blank" class="whatsapp-link">
                        <i class="fa-brands fa-whatsapp"></i> Chat via Whatsapp
                    </a>
                </div>
            </div>
        </div>
    </section>

    <!-- GALERI SECTION (EDGE TO EDGE) -->
    <section class="gallery-section" id="galeri">
        <div class="container">
            <p class="gallery-subtitle">MOMEN DI CAFE CANDARIA</p>
            <h2 class="gallery-title">Galeri Candaria</h2>
            <p class="gallery-desc">Dokumentasi suasana, event, dan keceriaan di cafe kami.</p>

            <div class="gallery-grid">
                <div class="gallery-item"><img src="<?php echo e(asset('images/cafe.jpg')); ?>" onerror="this.src='images/cafe.jpg'" alt="Foto Galeri 1"></div>
                <div class="gallery-item"><img src="<?php echo e(asset('images/TEH JUS.jpg')); ?>" onerror="this.src='images/teh jus.jpg'" alt="Foto Galeri 2"></div>
                <div class="gallery-item"><img src="<?php echo e(asset('images/DIMSUM.jpg')); ?>" onerror="this.src='images/dimsum.jpg'" alt="Foto Galeri 3"></div>
                <div class="gallery-item"><img src="<?php echo e(asset('images/DONAT.jpg')); ?>" onerror="this.src='images/donat.jpg'" alt="Foto Galeri 4"></div>
            </div>
        </div>
    </section>

    <!-- FOOTER (EDGE TO EDGE) -->
    <footer>
        <div class="container">
            <h3>Cafe Candaria</h3>
            <p>SMKN 2 PURWAKARTA</p>
            <div class="copyright">
                &copy; 2026 Cafe Candaria. All Rights Reserved.
            </div>
        </div>
    </footer>

    <!-- JAVASCRIPT UNTUK PAGINASI MENU (> 6 ITEMS) -->
    <script>
        const ITEMS_PER_PAGE = 6;
        let currentPage = 1;
        const menuCards = document.querySelectorAll('#menuGrid .menu-card');
        const totalItems = menuCards.length;
        const totalPages = Math.ceil(totalItems / ITEMS_PER_PAGE);

        function updateMenuDisplay() {
            if (totalItems <= ITEMS_PER_PAGE) {
                document.getElementById('menuPagination').style.display = 'none';
                menuCards.forEach(card => card.style.display = 'block');
                return;
            }

            document.getElementById('menuPagination').style.display = 'flex';

            const start = (currentPage - 1) * ITEMS_PER_PAGE;
            const end = start + ITEMS_PER_PAGE;

            menuCards.forEach((card, index) => {
                if (index >= start && index < end) {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
            });

            document.getElementById('pageInfo').innerText = `Halaman ${currentPage} dari ${totalPages}`;
            document.getElementById('prevBtn').disabled = (currentPage === 1);
            document.getElementById('nextBtn').disabled = (currentPage === totalPages);
        }

        function nextPage() {
            if (currentPage < totalPages) {
                currentPage++;
                updateMenuDisplay();
            }
        }

        function prevPage() {
            if (currentPage > 1) {
                currentPage--;
                updateMenuDisplay();
            }
        }

        document.addEventListener('DOMContentLoaded', updateMenuDisplay);
    </script>
</body>

</html><?php /**PATH C:\laragon\www\cafe-candaria\resources\views/beranda.blade.php ENDPATH**/ ?>