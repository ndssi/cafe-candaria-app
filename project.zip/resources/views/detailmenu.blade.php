<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Semua Menu - Cafe Candaria</title>
  <!-- Link CSS disesuaikan ke menu.css -->
  <link rel="stylesheet" href="{{ asset('css/detailmenu.css') }}">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,400;0,600;0,700;1,400;1,700&display=swap" rel="stylesheet">
</head>
<body>

  <div class="container">
    <!-- HEADER TITLES -->
    <header class="menu-header">
      <h1 class="main-title">SEMUA MENU</h1>
      <h2 class="sub-title">Cafe Candaria</h2>
    </header>

    <!-- GRID MENU CARDS -->
    <main class="menu-grid">
      <!-- Card 1 -->
      <div class="menu-card">
        <div class="card-img-wrapper">
          <img src="{{ asset('images/TEH JUS.jpg') }}" alt="Es Tea Jus">
        </div>
        <div class="card-body">
          <span class="category">MINUMAN</span>
          <h3 class="item-name">Es Tea Jus</h3>
          <span class="price">Rp 2.000</span>
        </div>
      </div>

      <!-- Card 2 -->
      <div class="menu-card">
        <div class="card-img-wrapper">
          <img src="{{ asset('images/CHOCOLATOS.jpg') }}" alt="Es Chocolatos">
        </div>
        <div class="card-body">
          <span class="category">MINUMAN</span>
          <h3 class="item-name">Es Chocolatos</h3>
          <span class="price">Rp 2.000</span>
        </div>
      </div>

      <!-- Card 3 -->
      <div class="menu-card">
        <div class="card-img-wrapper">
          <img src="{{ asset('images/R.jpg') }}" alt="AQUA">
        </div>
        <div class="card-body">
          <span class="category">MINUMAN</span>
          <h3 class="item-name">AQUA</h3>
          <span class="price">Rp 2.000</span>
        </div>
      </div>

      <!-- Card 4 -->
      <div class="menu-card">
        <div class="card-img-wrapper">
          <img src="{{ asset('images/DONAT.jpg') }}" alt="Donat">
        </div>
        <div class="card-body">
          <span class="category">MAKANAN</span>
          <h3 class="item-name">Donat</h3>
          <span class="price">Rp 4.000</span>
        </div>
      </div>

      <!-- Card 5 -->
      <div class="menu-card">
        <div class="card-img-wrapper">
          <img src="{{ asset('images/pisang.jpg') }}" alt="Pisang Crispi">
        </div>
        <div class="card-body">
          <span class="category">MAKANAN</span>
          <h3 class="item-name">Pisang Crispi</h3>
          <span class="price">Rp 4.000</span>
        </div>
      </div>

      <!-- Card 6 -->
      <div class="menu-card">
        <div class="card-img-wrapper">
          <img src="{{ asset('images/dimsum.jpg') }}" alt="Dimsum">
          <img src="{{ asset('images/DIMSUM.jpg') }}" alt="Dimsum">
        </div>
        <div class="card-body">
          <span class="category">MAKANAN</span>
          <h3 class="item-name">Dimsum</h3>
          <span class="price">Rp 7.000</span>
        </div>
      </div>
    </main>

    <!-- BUTTON KEMBALI -->
    <footer class="menu-footer">
      <a href="{{ route('beranda') }}" class="btn-back">Kembali Ke Beranda</a>
    </footer>
  </div>

</body>
</html>