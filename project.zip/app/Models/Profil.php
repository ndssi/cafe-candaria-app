<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Profil extends Model
{
    use HasFactory;

    // Nama tabel database
    protected $table = 'profils'; // Sesuaikan jika nama tabel Anda berbeda (misal: 'profil')

    // Kolom yang dapat diisi
    protected $fillable = [
        'judul',
        'isi',
        'gambar',
    ];
}