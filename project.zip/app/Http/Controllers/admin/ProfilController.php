<?php

namespace App\Http\Controllers;

use App\Models\Profil;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class ProfilController extends Controller
{
    /**
     * Menampilkan daftar profil.
     */
    public function index()
    {
        $profils = Profil::all();
        return view('admin.profil.index', compact('profils'));
    }

    /**
     * Menampilkan form tambah profil.
     */
    public function create()
    {
        return view('admin.profil.create');
    }

    /**
     * Menyimpan data profil baru ke database.
     */
    public function store(Request $request)
    {
        $request->validate([
            'judul'  => 'required|string|max:100',
            'isi'    => 'required|string',
            'gambar' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        ]);

        // Upload gambar ke storage/app/public/profil
        $gambarPath = $request->file('gambar')->store('profil', 'public');

        Profil::create([
            'judul'  => $request->judul,
            'isi'    => $request->isi,
            'gambar' => $gambarPath,
        ]);

        return redirect()->route('admin.profil.index')
                         ->with('success', 'Data profil berhasil ditambahkan!');
    }

    /**
     * Menampilkan form edit profil.
     */
    public function edit($id)
    {
        $profil = Profil::findOrFail($id);
        return view('admin.profil.edit', compact('profil'));
    }

    /**
     * Memperbarui data profil di database.
     */
    public function update(Request $request, $id)
    {
        $profil = Profil::findOrFail($id);

        $request->validate([
            'judul'  => 'required|string|max:100',
            'isi'    => 'required|string',
            'gambar' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        ]);

        $data = [
            'judul' => $request->judul,
            'isi'   => $request->isi,
        ];

        // Jika ada gambar baru yang diunggah
        if ($request->hasFile('gambar')) {
            // Hapus gambar lama jika ada
            if ($profil->gambar && Storage::disk('public')->exists($profil->gambar)) {
                Storage::disk('public')->delete($profil->gambar);
            }

            // Simpan gambar baru
            $data['gambar'] = $request->file('gambar')->store('profil', 'public');
        }

        $profil->update($data);

        return redirect()->route('admin.profil.index')
                         ->with('success', 'Data profil berhasil diperbarui!');
    }

    /**
     * Menghapus data profil.
     */
    public function destroy($id)
    {
        $profil = Profil::findOrFail($id);

        // Hapus file gambar dari storage
        if ($profil->gambar && Storage::disk('public')->exists($profil->gambar)) {
            Storage::disk('public')->delete($profil->gambar);
        }

        $profil->delete();

        return redirect()->route('admin.profil.index')
                         ->with('success', 'Data profil berhasil dihapus!');
    }
}