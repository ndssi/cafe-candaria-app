<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProfilController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('beranda');
})->name('beranda');

Route::get('/detailmenu', function (){
    return view('detailmenu');
})->name('detailmenu');

// HALAMAN ADMIN & SIDEBAR
Route::get('/admin/login', function () {
    return view('admin.login');
})->name('admin.login');

Route::get('/admin/dashboard', function () {
    return view('admin.dashboard');
})->name('admin.dashboard');

Route::get('/admin/profil', function () {
    return view('admin.profil');
})->name('admin.profil');

Route::get('/admin/editprofil', function () {
    return view('admin.editprofil');
})->name('admin.editprofil');

Route::get('/admin/organigram', function () {
    return view('admin.organigram');
})->name('admin.organigram');

Route::get('/admin/organigram/tambah', function () {
    return view('admin.tambahorganigram');
})->name('admin.organigram.tambah');

Route::get('/admin/tambahorganigram', function () {
    return view('admin.tambahorganigram');
})->name('admin.tambahorganigram');

Route::post('/admin/organigram/store', function () {
    // Logika simpan ke database
    return redirect()->route('admin.organigram');
})->name('admin.organigram.store');

Route::get('/admin/organigram/edit/{id?}', function ($id = null) {
    return view('admin.editorganigram', compact('id'));
})->name('admin.organigram.edit');

Route::get('/admin/editorganigram', function () {
    return view('admin.editorganigram');
})->name('admin.editorganigram');

Route::put('/admin/organigram/update/{id?}', function ($id = null) {
    // Logika update ke database
    return redirect()->route('admin.organigram');
})->name('admin.organigram.update');

Route::get('/admin/organigram/hapus/{id?}', function ($id = null) {
    return view('admin.hapusorganigram', compact('id'));
})->name('admin.organigram.hapus');

Route::get('/admin/hapusorganigram', function () {
    return view('admin.hapusorganigram');
})->name('admin.hapusorganigram');

Route::delete('/admin/organigram/destroy/{id?}', function ($id = null) {
    // Logika hapus dari database
    return redirect()->route('admin.organigram');
})->name('admin.organigram.destroy');


// ROUTE KELOLA MENU
Route::get('/admin/menu', function () {
    return view('admin.menu');
})->name('admin.menu');

Route::get('/admin/menu/create', function () {
    if (view()->exists('admin.tambahmenu')) {
        return view('admin.tambahmenu');
    }
    return view('admin.menu');
})->name('admin.menu.create');

Route::post('/admin/menu/store', function (\Illuminate\Http\Request $request) {
    if ($request->has('nama_menu')) {
        \App\Models\Menu::create([
            'nama_menu' => $request->input('nama_menu'),
            'deskripsi' => $request->input('deskripsi', ''),
            'harga'     => $request->input('harga', '0'),
        ]);
    }
    return redirect()->route('admin.menu');
})->name('admin.menu.store');

Route::get('/admin/menu/edit/{id?}', function ($id = null) {
    $menu = \App\Models\Menu::find($id);
    if (!$menu && $id) {
        $dummy = [
            1 => (object)['id' => 1, 'nama_menu' => 'Es Tea Jus', 'kategori' => 'Minuman', 'harga' => '2.000'],
            2 => (object)['id' => 2, 'nama_menu' => 'Dimsum', 'kategori' => 'Makanan', 'harga' => '7.000'],
            3 => (object)['id' => 3, 'nama_menu' => 'Es Bonteh', 'kategori' => 'Minuman', 'harga' => '4.000'],
            4 => (object)['id' => 4, 'nama_menu' => 'Pisang Crispy', 'kategori' => 'Makanan', 'harga' => '4.000'],
            5 => (object)['id' => 5, 'nama_menu' => 'Donat', 'kategori' => 'Makanan', 'harga' => '4.000'],
            6 => (object)['id' => 6, 'nama_menu' => 'AQUA', 'kategori' => 'Minuman', 'harga' => '2.000'],
            7 => (object)['id' => 7, 'nama_menu' => 'Es Chocolatos', 'kategori' => 'Minuman', 'harga' => '2.000'],
        ];
        $menu = $dummy[$id] ?? (object)['id' => $id, 'nama_menu' => '', 'kategori' => 'Minuman', 'harga' => ''];
    }
    return view('admin.editmenu', compact('id', 'menu'));
})->name('admin.menu.edit');

Route::put('/admin/menu/update/{id?}', function (\Illuminate\Http\Request $request, $id = null) {
    if ($id) {
        $menu = \App\Models\Menu::find($id);
        if ($menu) {
            $menu->update([
                'nama_menu' => $request->input('nama_menu', $menu->nama_menu),
                'harga'     => $request->input('harga', $menu->harga),
            ]);
        }
    }
    return redirect()->route('admin.menu');
})->name('admin.menu.update');

Route::get('/admin/menu/delete/{id?}', function ($id = null) {
    $menu = \App\Models\Menu::find($id);
    if (!$menu && $id) {
        $dummy = [
            1 => (object)['id' => 1, 'nama_menu' => 'Es Tea Jus'],
            2 => (object)['id' => 2, 'nama_menu' => 'Dimsum'],
            3 => (object)['id' => 3, 'nama_menu' => 'Es Bonteh'],
            4 => (object)['id' => 4, 'nama_menu' => 'Pisang Crispy'],
        ];
        $menu = $dummy[$id] ?? (object)['id' => $id, 'nama_menu' => 'Menu #' . $id];
    }
    return view('admin.hapusmenu', compact('id', 'menu'));
})->name('admin.menu.delete');

Route::delete('/admin/menu/destroy/{id?}', function ($id = null) {
    if ($id) {
        $menu = \App\Models\Menu::find($id);
        if ($menu) {
            $menu->delete();
        }
    }
    return redirect()->route('admin.menu');
})->name('admin.menu.destroy');



// ROUTE KELOLA JAM OPERASIONAL
Route::get('/admin/jam-operasional', function () {
    return view('admin.jam-operasional');
    return view('admin.jamoperasional');
})->name('admin.jam-operasional');

Route::get('/admin/jamoperasional', function () {
    return redirect()->route('admin.jam-operasional');
})->name('admin.jamoperasional');

Route::get('/admin/jam-operasional/edit/{id?}', function ($id = null) {
    if (view()->exists('admin.editjamoperasional')) {
        return view('admin.editjamoperasional', compact('id'));
    }
    return view('admin.jamoperasional', compact('id'));
})->name('admin.jam-operasional.edit');

Route::put('/admin/jam-operasional/update/{id?}', function ($id = null) {
    // Logika simpan perubahan jam operasional
    return redirect()->route('admin.jam-operasional');
})->name('admin.jam-operasional.update');

Route::get('/admin/jam-operasional/delete/{id?}', function ($id = null) {
    if (view()->exists('admin.hapusjamoperasional')) {
        return view('admin.hapusjamoperasional', compact('id'));
    }
    return view('admin.jamoperasional', compact('id'));
})->name('admin.jam-operasional.delete');

Route::delete('/admin/jam-operasional/destroy/{id?}', function ($id = null) {
    // Logika hapus jam operasional
    return redirect()->route('admin.jam-operasional');
})->name('admin.jam-operasional.destroy');

// ROUTE HAPUS DATA PROFIL (Sesuai dengan Blade)
Route::delete('/admin/profil/delete-judul', function () {
    return redirect()->route('admin.profil');
})->name('admin.profil.delete-judul');

Route::delete('/admin/profil/delete-sejarah', function () {
    return redirect()->route('admin.profil');
})->name('admin.profil.delete-sejarah');

Route::get('/admin/hapusprofil', function () {
    return view('admin.hapusprofil');
})->name('admin.hapusprofil');

// ROUTE AUTH / LOGIN / LOGOUT
Route::get('/login', function () {
    return redirect()->route('admin.login');
})->name('login');

Route::post('/logout', function () {
    return redirect()->route('admin.login');
})->name('logout');

// ROUTE KELOLA GALERI
Route::get('/admin/galeri', function () {
    $galleries = \App\Models\Galeri::all();
    return view('admin.galeri', compact('galleries'));
})->name('admin.galeri');

Route::get('/admin/galeri/edit/{id?}', function ($id = 1) {
    $galeri = \App\Models\Galeri::find($id);
    return view('admin.editgaleri', compact('id', 'galeri'));
})->name('admin.galeri.edit');

Route::get('/admin/editgaleri', function () {
    return view('admin.editgaleri');
})->name('admin.editgaleri');

Route::get('/admin/galeri/hapus/{id?}', function ($id = 1) {
    $galeri = \App\Models\Galeri::find($id);
    return view('admin.hapusgaleri', compact('id', 'galeri'));
})->name('admin.galeri.hapus');

Route::get('/admin/hapusgaleri', function () {
    return view('admin.hapusgaleri');
})->name('admin.hapusgaleri');

Route::delete('/admin/galeri/destroy/{id?}', function ($id = null) {
    if ($id) {
        $galeri = \App\Models\Galeri::find($id);
        if ($galeri) {
            $galeri->delete();
        }
    }
    return redirect()->route('admin.galeri');
})->name('admin.galeri.destroy');

// ALIAS ROUTE UNTUK KOMPATIBILITAS
Route::get('/galeri', function () {
    return redirect()->route('admin.galeri');
})->name('galeri.index');

Route::get('/galeri/edit/{id?}', function ($id = 1) {
    return redirect()->route('admin.galeri.edit', $id);
})->name('galeri.edit');

Route::delete('/galeri/destroy/{id?}', function ($id = null) {
    return redirect()->route('admin.galeri.destroy', $id);
})->name('galeri.destroy');

Route::prefix('admin')->name('admin.')->group(function () {
    Route::get('/admin/profil', [ProfilController::class, 'index'])->name('profil.index');
    Route::get('/admin/profil/create', [ProfilController::class, 'create'])->name('profil.create');
    Route::post('/admin/profil', [ProfilController::class, 'store'])->name('profil.store');
    Route::get('/admin/profil/{id}/edit', [ProfilController::class, 'edit'])->name('profil.edit');
    Route::put('/admin/profil/{id}', [ProfilController::class, 'update'])->name('profil.update');
    Route::delete('/admin/profil/{id}', [ProfilController::class, 'destroy'])->name('profil.destroy');
});
